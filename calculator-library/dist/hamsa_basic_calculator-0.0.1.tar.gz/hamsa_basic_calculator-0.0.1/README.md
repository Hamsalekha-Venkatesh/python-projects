This is a sample calculator class that provides the users features to use some basic mathematical operations like add, subtract, multiple and divide. 
So enjoyt this simple, yet, powerful module.